'use strict';

// ═══════════════════════════════════════════════════════════
// 🧠 UTILS JWT
// ═══════════════════════════════════════════════════════════
function isJWT(t) {
  return /^[A-Za-z0-9-_]+\.[A-Za-z0-9-_]+\.[A-Za-z0-9-_]+$/.test(t);
}

function getExp(tok) {
  try {
    const payload = JSON.parse(atob(tok.split('.')[1]));
    return payload.exp * 1000;
  } catch(e) {
    return Date.now() + 6 * 3600 * 1000;
  }
}

// ═══════════════════════════════════════════════════════════
// ⏱️ PLANIFICATION INTELLIGENTE
// ═══════════════════════════════════════════════════════════
async function scheduleFromToken(tok) {
  const exp = getExp(tok);

  // refresh 30 min avant expiration
  const refreshAt = exp - (30 * 60 * 1000);
  const delay = Math.max(60_000, refreshAt - Date.now());

  chrome.alarms.create('nc-auto', {
    when: Date.now() + delay
  });

  await chrome.storage.local.set({ ncNextRefresh: Date.now() + delay });

  console.log('[NC Ext] Refresh planifié dans', Math.round(delay/60000), 'min');
}

// ═══════════════════════════════════════════════════════════
// 🌐 INJECTION CAPTURE TOKEN
// ═══════════════════════════════════════════════════════════
function captureTokenInPage() {
  if (window.__ncHooked === true) return;
  Object.defineProperty(window, '__ncHooked', { value: true });

  function isJWT(t) {
    return /^[A-Za-z0-9-_]+\.[A-Za-z0-9-_]+\.[A-Za-z0-9-_]+$/.test(t);
  }

  function send(tok) {
    if (!tok || !isJWT(tok)) return;
    try { localStorage.setItem('__nc_jwt__', tok); } catch(e) {}
    window.postMessage({ type: '__nc_tok__', t: tok }, window.location.origin);
  }

  // XHR
  const _setRH = XMLHttpRequest.prototype.setRequestHeader;
  XMLHttpRequest.prototype.setRequestHeader = function(n, v) {
    if (n.toLowerCase() === 'authorization') {
      const t = v.replace(/^Bearer\s+/i, '');
      if (isJWT(t)) send(t);
    }
    return _setRH.call(this, n, v);
  };

  // fetch
  const _fetch = window.fetch;
  window.fetch = function(url, opts) {
    if (opts?.headers) {
      let a =
        (typeof opts.headers.get === 'function' ? opts.headers.get('Authorization') : null)
        || opts.headers.Authorization || opts.headers.authorization || '';
      const t = a.replace(/^Bearer\s+/i, '');
      if (isJWT(t)) send(t);
    }
    return _fetch.apply(this, arguments);
  };

  console.log('[NC Ext] Hooks actifs');
}

// ═══════════════════════════════════════════════════════════
// 💾 SUPABASE PUSH (optimisé)
// ═══════════════════════════════════════════════════════════
async function pushTokenToSupabase(tok) {
  try {
    await fetch('https://tiiptlozingmgzcnexpu.supabase.co/rest/v1/shared_tokens', {
      method: 'POST',
      headers: {
        'apikey': 'TON_ANON_KEY',
        'Authorization': 'Bearer TON_ANON_KEY',
        'Content-Type': 'application/json',
        'Prefer': 'resolution=merge-duplicates'
      },
      body: JSON.stringify({
        id: 'meteo-nc',
        token: tok,
        updated_at: new Date().toISOString()
      })
    });
  } catch(e) {}
}

// ═══════════════════════════════════════════════════════════
// 💾 SAVE TOKEN
// ═══════════════════════════════════════════════════════════
async function saveToken(tok) {
  if (!tok || !isJWT(tok)) return;

  const { ncToken } = await chrome.storage.local.get('ncToken');
  if (ncToken === tok) return;

  await chrome.storage.local.set({
    ncToken: tok,
    ncTokenDate: Date.now()
  });

  await pushTokenToSupabase(tok);
  await scheduleFromToken(tok);

  console.log('[NC Ext] Token updated');

  // push vers app
  const tabs = await chrome.tabs.query({ url: ['https://thibsurf.github.io/*'] });

  for (let tab of tabs) {
    try {
      chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: (t) => {
          localStorage.setItem('nc-token', t);
          window.dispatchEvent(new CustomEvent('nc-token-updated', { detail: t }));
        },
        args: [tok],
        world: 'MAIN'
      });
    } catch(e) {}
  }
}

// ═══════════════════════════════════════════════════════════
// 🔁 REFRESH FORCÉ (fallback)
// ═══════════════════════════════════════════════════════════
async function forceRefresh() {
  console.log('[NC Ext] Refresh forcé');

  const tab = await chrome.tabs.create({
    url: 'https://meteo.nc',
    active: false
  });

  setTimeout(() => {
    try { chrome.tabs.remove(tab.id); } catch(e) {}
  }, 15000);
}

// ═══════════════════════════════════════════════════════════
// EVENTS
// ═══════════════════════════════════════════════════════════

// injection
chrome.tabs.onUpdated.addListener((tabId, info, tab) => {
  if (tab.url?.includes('meteo.nc') && info.status === 'loading') {
    chrome.scripting.executeScript({
      target: { tabId },
      func: captureTokenInPage,
      world: 'MAIN'
    });
  }
});

// messages
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'NC_TOKEN') {
    saveToken(msg.token);
    sendResponse({ ok: true });
    return true;
  }

  if (msg.type === 'POPUP_GET') {
    chrome.storage.local.get(['ncToken', 'ncTokenDate', 'ncNextRefresh'], sendResponse);
    return true;
  }

  if (msg.type === 'FORCE_REFRESH') {
    forceRefresh().then(() => sendResponse({ ok: true }));
    return true;
  }
});

// alarme
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'nc-auto') {
    forceRefresh();
  }
});

// install
chrome.runtime.onInstalled.addListener(() => {
  chrome.alarms.create('nc-auto', { periodInMinutes: 360 });
});

// startup
chrome.runtime.onStartup.addListener(() => {
  chrome.storage.local.get(['ncToken'], (d) => {
    if (d.ncToken) scheduleFromToken(d.ncToken);
  });
});