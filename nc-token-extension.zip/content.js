// content.js — ISOLATED world sur meteo.nc
// Pont postMessage(MAIN) → chrome.runtime(background)
window.addEventListener('message', function(e) {
  if (e.source !== window || !e.data) return;
  if (e.data.type === '__nc_tok__' && e.data.t) {
    chrome.runtime.sendMessage({ type: 'NC_TOKEN', token: e.data.t });
  }
});
// Aussi lire localStorage après chargement complet (backup)
window.addEventListener('load', function() {
  setTimeout(function() {
    try {
      var tok = localStorage.getItem('__nc_jwt__');
      if (tok && tok.length > 30) {
        chrome.runtime.sendMessage({ type: 'NC_TOKEN', token: tok });
      }
    } catch(e) {}
  }, 2000);
});
