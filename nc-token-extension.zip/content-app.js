// content-app.js — ISOLATED world sur surf-journal
// Pousse le token vers le MAIN world de l'app via postMessage

function pushToken(tok) {
  if (!tok || tok.length < 30) return;
  // Envoyer immédiatement ET après un délai (pour que l'app soit prête)
  window.postMessage({ type: '__nc_set_token__', token: tok }, '*');
  setTimeout(function() {
    window.postMessage({ type: '__nc_set_token__', token: tok }, '*');
  }, 1500);
}

// Au DOMContentLoaded — l'app est probablement prête
document.addEventListener('DOMContentLoaded', function() {
  chrome.storage.local.get(['ncToken'], function(d) {
    if (d.ncToken) pushToken(d.ncToken);
  });
});

// Au chargement complet
window.addEventListener('load', function() {
  chrome.storage.local.get(['ncToken'], function(d) {
    if (d.ncToken) pushToken(d.ncToken);
  });
});

// Quand le token change dans storage (extension vient de capter un nouveau)
chrome.storage.onChanged.addListener(function(changes, area) {
  if (area === 'local' && changes.ncToken && changes.ncToken.newValue) {
    pushToken(changes.ncToken.newValue);
  }
});
