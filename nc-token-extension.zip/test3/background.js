'use strict';

// ═══════════════════════════════════════
// 🧠 VALIDATION JWT
// ═══════════════════════════════════════
function isJWT(t) {
  return typeof t === "string" &&
    /^[A-Za-z0-9-_]+\.[A-Za-z0-9-_]+\.[A-Za-z0-9-_]+$/.test(t);
}

// ═══════════════════════════════════════
// 💾 SAVE TOKEN (SOURCE UNIQUE)
// ═══════════════════════════════════════
async function saveToken(token) {
  if (!isJWT(token)) return;

  const data = await chrome.storage.local.get("ncToken");

  if (data.ncToken === token) return;

  await chrome.storage.local.set({
    ncToken: token,
    ncTokenDate: Date.now()
  });

  console.log("[BG] ✅ Token saved");
}

// ═══════════════════════════════════════
// 📩 MESSAGE HANDLER
// ═══════════════════════════════════════
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {

  // 📥 receive token
  if (msg.type === "NC_TOKEN") {
    console.log("[BG] 📩 token received");
    saveToken(msg.token);
    sendResponse({ ok: true });
    return true;
  }

  // 📤 popup read
  if (msg.type === "POPUP_GET") {
    chrome.storage.local.get(
      ["ncToken", "ncTokenDate"],
      (data) => {
        sendResponse(data || {});
      }
    );
    return true;
  }

  // 🔄 force refresh (optionnel)
  if (msg.type === "FORCE_REFRESH") {
    chrome.tabs.create({
      url: "https://meteo.nc",
      active: false
    });

    sendResponse({ ok: true });
    return true;
  }
});