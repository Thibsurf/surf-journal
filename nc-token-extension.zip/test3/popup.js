function $(id) {
  return document.getElementById(id);
}

function refresh() {
  const msg = $("msg");
  const dt = $("dt");

  if (msg) msg.textContent = "Chargement...";

  chrome.runtime.sendMessage({ type: "POPUP_GET" }, (d) => {

    if (chrome.runtime.lastError) {
      if (msg) msg.textContent = "❌ Extension inactive";
      return;
    }

    if (!d || !d.ncToken) {
      if (msg) msg.textContent = "❌ Aucun token";
      if (dt) dt.textContent = "";
      return;
    }

    if (msg) msg.textContent = "✅ Token actif";

    if (dt) {
      dt.textContent = new Date(d.ncTokenDate).toLocaleString();
    }
  });
}

// buttons
document.addEventListener("DOMContentLoaded", () => {

  const btnRefresh = $("btn-refresh");
  const btnApp = $("btn-app");

  if (btnRefresh) {
    btnRefresh.onclick = () => {
      chrome.runtime.sendMessage({ type: "FORCE_REFRESH" });
      setTimeout(refresh, 1500);
    };
  }

  if (btnApp) {
    btnApp.onclick = () => {
      chrome.tabs.create({
        url: "https://thibsurf.github.io/surf-journal/previsions.html"
      });
    };
  }

  refresh();
});