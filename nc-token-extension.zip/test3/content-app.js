chrome.storage.local.get(["ncToken"], (d) => {
  if (d.ncToken) {
    window.postMessage({
      type: "__nc_set_token__",
      token: d.ncToken
    }, "*");
  }
});

chrome.storage.onChanged.addListener((changes, area) => {
  if (area === "local" && changes.ncToken) {
    window.postMessage({
      type: "__nc_set_token__",
      token: changes.ncToken.newValue
    }, "*");
  }
});