'use strict';

// ═══════════════════════════════
// 🧠 JWT CHECK
// ═══════════════════════════════
function isJWT(t) {
  return typeof t === "string" &&
    /^[A-Za-z0-9-_]+\.[A-Za-z0-9-_]+\.[A-Za-z0-9-_]+$/.test(t);
}

// ═══════════════════════════════
// 🔍 SCAN PAGE (DOM + SCRIPT + STORAGE)
// ═══════════════════════════════
function scanForToken() {
  try {
    // 1. localStorage fallback
    const ls = localStorage.getItem("__nc_jwt__");
    if (isJWT(ls)) {
      chrome.runtime.sendMessage({ type: "NC_TOKEN", token: ls });
      return;
    }

    // 2. scan scripts inline
    const scripts = document.querySelectorAll("script");

    for (const s of scripts) {
      const txt = s.textContent || "";

      const match = txt.match(
        /eyJ[A-Za-z0-9-_]+\.[A-Za-z0-9-_]+\.[A-Za-z0-9-_]+/
      );

      if (match && isJWT(match[0])) {
        chrome.runtime.sendMessage({
          type: "NC_TOKEN",
          token: match[0]
        });

        return;
      }
    }

  } catch (e) {}
}

// ═══════════════════════════════
// 🚀 OBSERVER (IMPORTANT)
// ═══════════════════════════════
const observer = new MutationObserver(() => {
  scanForToken();
});

observer.observe(document.documentElement, {
  childList: true,
  subtree: true
});

// run initial
window.addEventListener("load", () => {
  setTimeout(scanForToken, 1500);
});

console.log("[CONTENT] DOM scanner active");