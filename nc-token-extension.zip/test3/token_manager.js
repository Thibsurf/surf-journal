// ═══════════════════════════════════════════════════════════
// 🌐 CONFIG
// ═══════════════════════════════════════════════════════════
const SUPABASE_URL =
  'https://tiiptlozingmgzcnexpu.supabase.co/rest/v1/shared_tokens?id=eq.meteo-nc&select=token';

// ═══════════════════════════════════════════════════════════
// 💾 LOCAL TOKEN
// ═══════════════════════════════════════════════════════════
function getLocalToken() {
  try { return localStorage.getItem('nc-token'); } catch(e) { return null; }
}

function setLocalToken(tok) {
  try {
    localStorage.setItem('nc-token', tok);
    window.dispatchEvent(new CustomEvent('nc-token-updated', { detail: tok }));
  } catch(e) {}
}

// ═══════════════════════════════════════════════════════════
// 🔄 SYNC SUPABASE
// ═══════════════════════════════════════════════════════════
async function syncTokenFromSupabase() {
  try {
    const res = await fetch(SUPABASE_URL);
    const data = await res.json();

    if (!data?.[0]?.token) return false;

    const newTok = data[0].token;
    const localTok = getLocalToken();

    if (newTok !== localTok) {
      setLocalToken(newTok);
      console.log('[Token] Updated from Supabase');
      return true;
    }

    return false;
  } catch(e) {
    console.warn('[Token] Sync failed');
    return false;
  }
}

// ═══════════════════════════════════════════════════════════
// 🚀 INIT GLOBAL
// ═══════════════════════════════════════════════════════════
function initTokenManager() {
  // 1. sync immédiate
  syncTokenFromSupabase();

  // 2. refresh régulier (léger)
  setInterval(syncTokenFromSupabase, 5 * 60 * 1000);

  // 3. quand réseau revient
  window.addEventListener('online', syncTokenFromSupabase);

  // 4. écoute extension (postMessage)
  window.addEventListener('message', (e) => {
    if (e.data?.type === '__nc_set_token__') {
      setLocalToken(e.data.token);
      console.log('[Token] Updated from extension');
    }
  });
}

// auto-init
initTokenManager();