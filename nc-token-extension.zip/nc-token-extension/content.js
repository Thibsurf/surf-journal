// Content script ISOLATED sur meteo.nc
// Écoute postMessage depuis MAIN et forward vers background
window.addEventListener('message', function(e) {
  if (e.source !== window) return;
  if (e.data && e.data.type === '__nc_token__' && e.data.token) {
    chrome.runtime.sendMessage({ type: 'SAVE_TOKEN', token: e.data.token });
  }
});
console.log('[NC Token] content script meteo.nc prêt');
