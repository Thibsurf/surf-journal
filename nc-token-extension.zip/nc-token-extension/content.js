// Rien à faire — background.js injecte directement via tabs.onUpdated
console.log('[NC Token] content script chargé sur', window.location.hostname);
