function fmtDate(ts) {
  if (!ts) return '';
  var d = new Date(ts);
  return 'Capturé le ' + d.toLocaleDateString('fr-FR') + ' à ' + d.toLocaleTimeString('fr-FR', {hour:'2-digit',minute:'2-digit'});
}
function fmtNext(ts) {
  if (!ts) return '';
  var diff = ts - Date.now();
  if (diff <= 0) return 'Renouvellement imminent';
  var h = Math.floor(diff / 3600000);
  var m = Math.floor((diff % 3600000) / 60000);
  return 'Prochain renouvellement dans ' + h + 'h' + (m > 0 ? m + 'min' : '');
}

function showToken(tok, ts, next) {
  document.getElementById('msg').className = 'box ok';
  document.getElementById('msg').textContent = '✅ Token actif';
  document.getElementById('area').style.display = 'block';
  document.getElementById('tok').value = tok;
  document.getElementById('dt').textContent = fmtDate(ts);
  document.getElementById('nxt').textContent = fmtNext(next);
}
function showErr(txt) {
  document.getElementById('msg').className = 'box err';
  document.getElementById('msg').textContent = txt;
  document.getElementById('area').style.display = 'none';
}
function showLoading(txt) {
  document.getElementById('msg').className = 'box info';
  document.getElementById('msg').innerHTML = '<span class="spinner"></span>' + (txt || 'En cours...');
  document.getElementById('area').style.display = 'none';
}

function refresh() {
  chrome.runtime.sendMessage({ type: 'POPUP_GET_TOKEN' }, function(resp) {
    if (resp && resp.token) {
      showToken(resp.token, resp.date, resp.next);
    } else {
      showErr('❌ ' + ((resp && resp.error) || 'Pas de token') + '\n→ Clique "Renouveler maintenant"');
    }
  });
}

document.getElementById('btn-copy').addEventListener('click', function() {
  var t = document.getElementById('tok').value;
  navigator.clipboard.writeText(t).then(function() {
    document.getElementById('msg').textContent = '✅ Copié ! Colle dans Surf NC via 🔑';
  }).catch(function() {
    document.getElementById('tok').select();
    document.execCommand('copy');
    document.getElementById('msg').textContent = '✅ Copié !';
  });
});

document.getElementById('btn-refresh').addEventListener('click', function() {
  showLoading('Ouverture de meteo.nc en arrière-plan (~12s)...');
  chrome.runtime.sendMessage({ type: 'FORCE_REFRESH' }, function(resp) {
    if (resp && resp.ok) {
      setTimeout(refresh, 500);
    } else {
      showErr('❌ Échec renouvellement : ' + (resp && resp.error || 'inconnu'));
    }
  });
});

document.getElementById('btn-read').addEventListener('click', function() {
  showLoading('Lecture depuis l\'onglet meteo.nc...');
  chrome.runtime.sendMessage({ type: 'POPUP_GET_TOKEN' }, function(resp) {
    if (resp && resp.token) showToken(resp.token, resp.date, resp.next);
    else showErr('❌ Pas d\'onglet meteo.nc ouvert');
  });
});

document.getElementById('btn-clear').addEventListener('click', function() {
  chrome.storage.local.clear(function() { showErr('Storage vidé'); });
});

refresh();
