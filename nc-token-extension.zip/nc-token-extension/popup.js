function fmtDate(ts) {
  if (!ts) return '';
  var d = new Date(ts);
  return 'Capturé le ' + d.toLocaleDateString('fr-FR') + ' à ' + d.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' });
}
function fmtNext(ts) {
  if (!ts || ts < Date.now()) return 'Renouvellement imminent';
  var h = Math.floor((ts - Date.now()) / 3600000);
  var m = Math.floor(((ts - Date.now()) % 3600000) / 60000);
  return 'Prochain renouvellement dans ' + h + 'h' + (m > 0 ? m + 'min' : '');
}

function refresh() {
  chrome.runtime.sendMessage({ type: 'POPUP_GET' }, function(d) {
    var msg = document.getElementById('msg');
    var dt = document.getElementById('dt');
    var nxt = document.getElementById('nxt');
    if (d && d.ncToken) {
      msg.className = 'box ok';
      msg.innerHTML = '✅ <b>Token actif</b><br><span style="font-size:10px;font-weight:400;">Synchronisé automatiquement avec Surf NC</span>';
      dt.textContent = fmtDate(d.ncTokenDate);
      nxt.textContent = fmtNext(d.ncNextRefresh);
    } else {
      msg.className = 'box err';
      msg.textContent = '❌ Pas de token — clique Renouveler';
      dt.textContent = '';
      if (nxt) nxt.textContent = '';
    }
  });
}

document.getElementById('btn-refresh').addEventListener('click', function() {
  var msg = document.getElementById('msg');
  msg.className = 'box info';
  msg.innerHTML = '<span class="spinner"></span>Ouverture meteo.nc (~15s)...';
  chrome.runtime.sendMessage({ type: 'FORCE_REFRESH' }, function() {
    setTimeout(refresh, 1000);
  });
});

document.getElementById('btn-app').addEventListener('click', function() {
  chrome.tabs.create({ url: 'https://thibsurf.github.io/surf-journal/previsions.html' });
});

refresh();
