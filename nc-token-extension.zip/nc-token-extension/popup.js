function showToken(tok, ts) {
  document.getElementById('msg').className = 'box ok';
  document.getElementById('msg').textContent = '✅ Token prêt';
  document.getElementById('area').style.display = 'block';
  document.getElementById('tok').value = tok;
  document.getElementById('dt').textContent = ts ?
    'Capturé le ' + new Date(ts).toLocaleString('fr-FR') : '';
}
function showErr(txt) {
  document.getElementById('msg').className = 'box err';
  document.getElementById('msg').textContent = txt;
  document.getElementById('area').style.display = 'none';
}

function refresh() {
  showErr('Recherche...');
  // 1. Storage local
  chrome.storage.local.get(['ncToken','ncTokenDate'], function(d) {
    if (d.ncToken) { showToken(d.ncToken, d.ncTokenDate); return; }
    // 2. Lire depuis localStorage de l'onglet meteo.nc via background
    chrome.runtime.sendMessage({ type: 'POPUP_GET_TOKEN' }, function(resp) {
      if (resp && resp.token) {
        showToken(resp.token, Date.now());
      } else {
        var err = resp && resp.error ? resp.error : 'inconnu';
        showErr('❌ ' + err + '\n→ Recharge meteo.nc et réessaie');
      }
    });
  });
}

document.getElementById('btn-copy').addEventListener('click', function() {
  var t = document.getElementById('tok').value;
  navigator.clipboard.writeText(t).then(function() {
    document.getElementById('msg').textContent = '✅ Copié ! Colle dans Surf NC via 🔑';
  }).catch(function() {
    document.getElementById('tok').select(); document.execCommand('copy');
  });
});
document.getElementById('btn-refresh').addEventListener('click', refresh);
document.getElementById('btn-clear').addEventListener('click', function() {
  chrome.storage.local.clear(function() { showErr('Storage vidé'); });
});

refresh();
