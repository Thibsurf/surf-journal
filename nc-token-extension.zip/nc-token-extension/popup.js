function fmtDate(ts) {
  if (!ts) return '';
  var d = new Date(ts);
  return 'Token capturé : ' + d.toLocaleDateString('fr-FR') + ' à ' + d.toLocaleTimeString('fr-FR',{hour:'2-digit',minute:'2-digit'});
}

function refresh() {
  chrome.runtime.sendMessage({ type: 'POPUP_GET_TOKEN' }, function(resp) {
    var msg = document.getElementById('msg');
    var dt = document.getElementById('dt');
    if (resp && resp.token) {
      msg.className = 'box ok';
      msg.innerHTML = '✅ <b>Token actif</b><br><span style="font-size:10px;font-weight:400;">Synchronisé automatiquement avec l\'app Surf NC</span>';
      dt.textContent = fmtDate(resp.date);
    } else {
      msg.className = 'box err';
      msg.textContent = '❌ Pas de token — clique "Renouveler"';
      dt.textContent = '';
    }
  });
}

document.getElementById('btn-refresh').addEventListener('click', function() {
  var msg = document.getElementById('msg');
  msg.className = 'box info';
  msg.innerHTML = '<span class="spinner"></span>Ouverture meteo.nc en arrière-plan (~12s)...';
  chrome.runtime.sendMessage({ type: 'FORCE_REFRESH' }, function(resp) {
    setTimeout(refresh, 500);
  });
});

document.getElementById('btn-app').addEventListener('click', function() {
  chrome.tabs.create({ url: 'https://thibsurf.github.io/surf-journal/previsions.html' });
});

refresh();
