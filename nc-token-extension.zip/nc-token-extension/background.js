function captureTokenInPage() {
  if (window.__ncTokenHooked) return;
  window.__ncTokenHooked = true;

  function save(tok) {
    if (!tok || tok.length < 30) return;
    try { localStorage.setItem('__nc_jwt__', tok); } catch(e) {}
    window.postMessage({ type: '__nc_token__', token: tok }, '*');
  }

  var origSetRH = XMLHttpRequest.prototype.setRequestHeader;
  XMLHttpRequest.prototype.setRequestHeader = function(name, value) {
    if (name.toLowerCase() === 'authorization' && value.includes('eyJ'))
      save(value.replace(/^Bearer\s+/i, ''));
    return origSetRH.call(this, name, value);
  };

  var origFetch = window.fetch;
  window.fetch = function(url, opts) {
    if (opts && opts.headers) {
      var h = opts.headers;
      var a = (typeof h.get==='function' ? h.get('Authorization') : null)
              || h.Authorization || h.authorization || '';
      if (a.includes('eyJ')) save(a.replace(/^Bearer\s+/i, ''));
    }
    return origFetch.apply(this, arguments);
  };

  function hookjQ() {
    var jq = window.jQuery || window.$;
    if (!jq || jq.__nc_hooked) return;
    jq.__nc_hooked = true;
    try {
      jq.ajaxPrefilter(function(opts) {
        var a = (opts.headers||{}).Authorization || (opts.headers||{}).authorization || '';
        if (a.includes('eyJ')) save(a.replace(/^Bearer\s+/i, ''));
      });
    } catch(e) {}
  }
  [0,200,500,1000,2000,3000,5000].forEach(function(t){ setTimeout(hookjQ, t); });
}

function readToken() {
  return localStorage.getItem('__nc_jwt__');
}

function injectInTab(tabId) {
  chrome.scripting.executeScript({
    target: { tabId: tabId },
    func: captureTokenInPage,
    world: 'MAIN',
    injectImmediately: true
  }).catch(function(){});
}

chrome.tabs.onUpdated.addListener(function(tabId, info, tab) {
  if (!tab.url || !tab.url.includes('meteo.nc')) return;
  if (info.status === 'loading') injectInTab(tabId);
});

// Listener postMessage du MAIN world → sauvegarder dans chrome.storage
chrome.runtime.onMessage.addListener(function(msg, sender, sendResponse) {
  if (msg.type === 'SAVE_TOKEN' && msg.token) {
    chrome.storage.local.set({ ncToken: msg.token, ncTokenDate: Date.now() });
    sendResponse({ok: true});
    return true;
  }
  if (msg.type === 'POPUP_GET_TOKEN') {
    chrome.storage.local.get(['ncToken', 'ncTokenDate', 'ncNextRefresh'], function(d) {
      sendResponse({ token: d.ncToken || null, date: d.ncTokenDate, next: d.ncNextRefresh });
    });
    return true;
  }
  if (msg.type === 'FORCE_REFRESH') {
    autoRefreshToken().then(function(){ sendResponse({ok:true}); })
      .catch(function(e){ sendResponse({ok:false, error:e.message}); });
    return true;
  }
});

// Écouter postMessage depuis content script meteo.nc (via une astuce)
// Le MAIN world envoie via window.postMessage → le content script ISOLATED
// Mais on a supprimé le content.js fonctionnel — rajoutons-le
// En fait: scripting.executeScript avec world:'MAIN' ne peut pas communiquer
// directement avec background. Il faut passer par un content script ISOLATED.

// Réinjecter aussi un listener ISOLATED qui capte window.postMessage
function listenTokenInContent() {
  window.addEventListener('message', function(e) {
    if (e.source !== window) return;
    if (e.data && e.data.type === '__nc_token__' && e.data.token) {
      chrome.runtime.sendMessage({ type: 'SAVE_TOKEN', token: e.data.token });
    }
  });
}

chrome.tabs.onUpdated.addListener(function(tabId, info, tab) {
  if (!tab.url || !tab.url.includes('meteo.nc')) return;
  if (info.status === 'loading') {
    // Injecter le MAIN capteur
    injectInTab(tabId);
    // Injecter le listener ISOLATED
    chrome.scripting.executeScript({
      target: { tabId: tabId },
      func: listenTokenInContent,
      world: 'ISOLATED'
    }).catch(function(){});
  }
});

// ─── Renouvellement auto toutes les 6h ──────────────────────────────────────
async function autoRefreshToken() {
  var tabs = await chrome.tabs.query({ url: 'https://meteo.nc/*' });

  if (tabs.length > 0) {
    var results = await chrome.scripting.executeScript({
      target: { tabId: tabs[0].id },
      func: readToken,
      world: 'MAIN'
    }).catch(function(){ return null; });
    var tok = results && results[0] && results[0].result;
    if (tok) {
      await chrome.storage.local.set({ ncToken: tok, ncTokenDate: Date.now() });
      console.log('[NC Token] Lu depuis onglet existant');
      return;
    }
  }

  var newTab = await chrome.tabs.create({
    url: 'https://meteo.nc',
    active: false
  });
  var tabId = newTab.id;

  await new Promise(function(r){ setTimeout(r, 12000); });

  var res = await chrome.scripting.executeScript({
    target: { tabId: tabId },
    func: readToken,
    world: 'MAIN'
  }).catch(function(){ return null; });

  var token = res && res[0] && res[0].result;
  if (token) {
    await chrome.storage.local.set({ ncToken: token, ncTokenDate: Date.now() });
    console.log('[NC Token] Renouvelé automatiquement');
  }
  chrome.tabs.remove(tabId).catch(function(){});
}

// Utiliser chrome.alarms pour le renouvellement (plus fiable que setTimeout)
chrome.alarms.create('nc-refresh', { periodInMinutes: 360 }); // 6h

chrome.alarms.onAlarm.addListener(function(alarm) {
  if (alarm.name === 'nc-refresh') {
    autoRefreshToken();
    chrome.storage.local.set({ ncNextRefresh: Date.now() + 360 * 60 * 1000 });
  }
});

chrome.runtime.onInstalled.addListener(function() {
  setTimeout(autoRefreshToken, 2000);
  chrome.storage.local.set({ ncNextRefresh: Date.now() + 360 * 60 * 1000 });
});

chrome.runtime.onStartup.addListener(function() {
  chrome.storage.local.get(['ncTokenDate'], function(d) {
    var age = Date.now() - (d.ncTokenDate || 0);
    if (age > 20 * 60 * 60 * 1000) {
      setTimeout(autoRefreshToken, 3000);
    }
  });
});
