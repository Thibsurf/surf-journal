function captureTokenInPage() {
  if (window.__ncTokenHooked) return;
  window.__ncTokenHooked = true;

  function send(tok) {
    if (!tok || tok.length < 30) return;
    try { localStorage.setItem('__nc_jwt__', tok); } catch(e) {}
    console.log('[NC Token] capturé et stocké dans localStorage');
  }

  var origSetRH = XMLHttpRequest.prototype.setRequestHeader;
  XMLHttpRequest.prototype.setRequestHeader = function(name, value) {
    if (name.toLowerCase() === 'authorization' && value.includes('eyJ'))
      send(value.replace(/^Bearer\s+/i, ''));
    return origSetRH.call(this, name, value);
  };

  var origFetch = window.fetch;
  window.fetch = function(url, opts) {
    if (opts && opts.headers) {
      var h = opts.headers;
      var a = (typeof h.get==='function' ? h.get('Authorization') : null)
              || h.Authorization || h.authorization || '';
      if (a.includes('eyJ')) send(a.replace(/^Bearer\s+/i, ''));
    }
    return origFetch.apply(this, arguments);
  };

  function hookjQ() {
    var jq = window.jQuery || window.$;
    if (!jq || jq.__nc_hooked) return;
    jq.__nc_hooked = true;
    try {
      jq.ajaxPrefilter(function(opts) {
        var a = (opts.headers||{}).Authorization || (opts.headers||{}).authorization || '';
        if (a.includes('eyJ')) send(a.replace(/^Bearer\s+/i, ''));
      });
    } catch(e) {}
  }
  [0,200,500,1000,2000,3000,5000].forEach(function(t){ setTimeout(hookjQ, t); });
  console.log('[NC Token] hooks installés');
}

// Injecter dès que la page meteo.nc commence à charger
chrome.tabs.onUpdated.addListener(function(tabId, info, tab) {
  if (!tab.url || !tab.url.includes('meteo.nc')) return;
  // Injecter à document_start via scripting
  if (info.status === 'loading') {
    chrome.scripting.executeScript({
      target: { tabId: tabId },
      func: captureTokenInPage,
      world: 'MAIN',
      injectImmediately: true
    }).catch(function(){});
  }
});

// La popup lit localStorage directement
function readToken() {
  return localStorage.getItem('__nc_jwt__');
}

chrome.runtime.onMessage.addListener(function(msg, sender, sendResponse) {
  if (msg.type === 'POPUP_GET_TOKEN') {
    // Chercher un onglet meteo.nc
    chrome.tabs.query({ url: 'https://meteo.nc/*' }, function(tabs) {
      if (!tabs.length) { sendResponse({ token: null, error: 'Pas d\'onglet meteo.nc ouvert' }); return; }
      chrome.scripting.executeScript({
        target: { tabId: tabs[0].id },
        func: readToken,
        world: 'MAIN'
      }).then(function(res) {
        var tok = res && res[0] && res[0].result;
        if (tok) chrome.storage.local.set({ ncToken: tok, ncTokenDate: Date.now() });
        sendResponse({ token: tok || null });
      }).catch(function(e) { sendResponse({ token: null, error: e.message }); });
    });
    return true; // async
  }
});
