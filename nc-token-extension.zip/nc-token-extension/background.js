// ─── Capture du token ────────────────────────────────────────────────────────
function captureTokenInPage() {
  if (window.__ncTokenHooked) return;
  window.__ncTokenHooked = true;

  function save(tok) {
    if (!tok || tok.length < 30) return;
    try { localStorage.setItem('__nc_jwt__', tok); } catch(e) {}
    window.postMessage({ type: '__nc_token__', token: tok }, '*');
  }

  var origSetRH = XMLHttpRequest.prototype.setRequestHeader;
  XMLHttpRequest.prototype.setRequestHeader = function(name, value) {
    if (name.toLowerCase() === 'authorization' && value.includes('eyJ'))
      save(value.replace(/^Bearer\s+/i, ''));
    return origSetRH.call(this, name, value);
  };

  var origFetch = window.fetch;
  window.fetch = function(url, opts) {
    if (opts && opts.headers) {
      var h = opts.headers;
      var a = (typeof h.get==='function' ? h.get('Authorization') : null)
              || h.Authorization || h.authorization || '';
      if (a.includes('eyJ')) save(a.replace(/^Bearer\s+/i, ''));
    }
    return origFetch.apply(this, arguments);
  };

  function hookjQ() {
    var jq = window.jQuery || window.$;
    if (!jq || jq.__nc_hooked) return;
    jq.__nc_hooked = true;
    try {
      jq.ajaxPrefilter(function(opts) {
        var a = (opts.headers||{}).Authorization || (opts.headers||{}).authorization || '';
        if (a.includes('eyJ')) save(a.replace(/^Bearer\s+/i, ''));
      });
    } catch(e) {}
  }
  [0,200,500,1000,2000,3000,5000].forEach(function(t){ setTimeout(hookjQ, t); });
}

function readToken() {
  return localStorage.getItem('__nc_jwt__');
}

// ─── Injection dans un onglet ────────────────────────────────────────────────
function injectInTab(tabId) {
  chrome.scripting.executeScript({
    target: { tabId: tabId },
    func: captureTokenInPage,
    world: 'MAIN',
    injectImmediately: true
  }).catch(function(e){ console.log('[NC Token] inject err:', e.message); });
}

// ─── Onglets meteo.nc existants ──────────────────────────────────────────────
chrome.tabs.onUpdated.addListener(function(tabId, info, tab) {
  if (!tab.url || !tab.url.includes('meteo.nc')) return;
  if (info.status === 'loading') injectInTab(tabId);
});

// ─── Renouvellement automatique ──────────────────────────────────────────────
var AUTO_REFRESH_INTERVAL = 6 * 60 * 60 * 1000; // 6h
var _autoTabId = null;
var _autoRefreshTimer = null;

async function autoRefreshToken() {
  console.log('[NC Token] Renouvellement automatique...');

  // Vérifier si un onglet meteo.nc est déjà ouvert
  var tabs = await chrome.tabs.query({ url: 'https://meteo.nc/*' });

  if (tabs.length > 0) {
    // Utiliser l'onglet existant — juste relire localStorage
    var results = await chrome.scripting.executeScript({
      target: { tabId: tabs[0].id },
      func: readToken,
      world: 'MAIN'
    }).catch(function(){ return null; });
    var tok = results && results[0] && results[0].result;
    if (tok) {
      await chrome.storage.local.set({ ncToken: tok, ncTokenDate: Date.now() });
      console.log('[NC Token] Token lu depuis onglet existant');
      scheduleNextRefresh();
      return;
    }
  }

  // Ouvrir un onglet meteo.nc en arrière-plan (non-focusé)
  var newTab = await chrome.tabs.create({
    url: 'https://meteo.nc',
    active: false  // onglet en arrière-plan
  });
  _autoTabId = newTab.id;

  // Attendre que la page charge et que les requêtes API partent (~10s)
  await new Promise(function(resolve){ setTimeout(resolve, 12000); });

  // Lire le token depuis localStorage
  var res = await chrome.scripting.executeScript({
    target: { tabId: _autoTabId },
    func: readToken,
    world: 'MAIN'
  }).catch(function(){ return null; });

  var token = res && res[0] && res[0].result;

  if (token) {
    await chrome.storage.local.set({ ncToken: token, ncTokenDate: Date.now() });
    console.log('[NC Token] Token renouvelé automatiquement ✓');
  } else {
    console.log('[NC Token] Échec renouvellement auto');
  }

  // Fermer l'onglet silencieux
  chrome.tabs.remove(_autoTabId).catch(function(){});
  _autoTabId = null;

  scheduleNextRefresh();
}

function scheduleNextRefresh() {
  if (_autoRefreshTimer) clearTimeout(_autoRefreshTimer);
  _autoRefreshTimer = setTimeout(autoRefreshToken, AUTO_REFRESH_INTERVAL);
  // Sauvegarder la prochaine heure prévue
  chrome.storage.local.set({ ncNextRefresh: Date.now() + AUTO_REFRESH_INTERVAL });
}

// ─── Démarrage ───────────────────────────────────────────────────────────────
chrome.runtime.onInstalled.addListener(function() {
  // Premier lancement: tenter une capture immédiate
  setTimeout(autoRefreshToken, 2000);
});

chrome.runtime.onStartup.addListener(function() {
  // Au démarrage du navigateur: vérifier si le token est périmé
  chrome.storage.local.get(['ncTokenDate'], function(d) {
    var age = Date.now() - (d.ncTokenDate || 0);
    var TOKEN_MAX_AGE = 20 * 60 * 60 * 1000; // 20h
    if (age > TOKEN_MAX_AGE) {
      console.log('[NC Token] Token périmé (' + Math.round(age/3600000) + 'h), renouvellement...');
      setTimeout(autoRefreshToken, 3000);
    } else {
      scheduleNextRefresh();
    }
  });
});

// ─── Messages de la popup ────────────────────────────────────────────────────
chrome.runtime.onMessage.addListener(function(msg, sender, sendResponse) {

  if (msg.type === 'POPUP_GET_TOKEN') {
    chrome.storage.local.get(['ncToken','ncTokenDate','ncNextRefresh'], function(d) {
      if (d.ncToken) { sendResponse({ token: d.ncToken, date: d.ncTokenDate, next: d.ncNextRefresh }); return; }
      // Pas de token en storage → essayer de lire depuis un onglet ouvert
      chrome.tabs.query({ url: 'https://meteo.nc/*' }, function(tabs) {
        if (!tabs.length) { sendResponse({ token: null, error: 'Pas de token — renouvellement en cours...' }); return; }
        chrome.scripting.executeScript({
          target: { tabId: tabs[0].id },
          func: readToken,
          world: 'MAIN'
        }).then(function(res) {
          var tok = res && res[0] && res[0].result;
          if (tok) chrome.storage.local.set({ ncToken: tok, ncTokenDate: Date.now() });
          sendResponse({ token: tok || null });
        }).catch(function(e) { sendResponse({ token: null, error: e.message }); });
      });
    });
    return true; // async
  }

  if (msg.type === 'FORCE_REFRESH') {
    autoRefreshToken().then(function() {
      sendResponse({ ok: true });
    }).catch(function(e) {
      sendResponse({ ok: false, error: e.message });
    });
    return true;
  }
});
