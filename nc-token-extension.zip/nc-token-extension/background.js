'use strict';

// ═══════════════════════════════════════════════════════════
// CAPTURE DU TOKEN (injectée dans MAIN world de meteo.nc)
// ═══════════════════════════════════════════════════════════
function captureTokenInPage() {
  if (window.__ncHooked) return;
  window.__ncHooked = true;

  function send(tok) {
    if (!tok || tok.length < 30) return;
    try { localStorage.setItem('__nc_jwt__', tok); } catch(e) {}
    // postMessage vers le monde ISOLATED (content.js l'écoute)
    window.postMessage({ type: '__nc_tok__', t: tok }, '*');
  }

  // Hook XHR
  var _open = XMLHttpRequest.prototype.open;
  var _setRH = XMLHttpRequest.prototype.setRequestHeader;
  XMLHttpRequest.prototype.setRequestHeader = function(n, v) {
    if (n.toLowerCase() === 'authorization' && v.includes('eyJ'))
      send(v.replace(/^Bearer\s+/i, ''));
    return _setRH.call(this, n, v);
  };

  // Hook fetch
  var _fetch = window.fetch;
  window.fetch = function(url, opts) {
    if (opts && opts.headers) {
      var h = opts.headers, a =
        (typeof h.get === 'function' ? h.get('Authorization') : null)
        || h.Authorization || h.authorization || '';
      if (a.includes('eyJ')) send(a.replace(/^Bearer\s+/i, ''));
    }
    return _fetch.apply(this, arguments);
  };

  // Hook jQuery (plusieurs tentatives car jQuery se charge après)
  function hookjQ() {
    var $ = window.jQuery || window.$;
    if (!$ || $.__ncH) return;
    $.__ncH = true;
    try {
      $.ajaxPrefilter(function(o) {
        var a = (o.headers || {}).Authorization || '';
        if (a.includes('eyJ')) send(a.replace(/^Bearer\s+/i, ''));
      });
    } catch(e) {}
  }
  [0, 300, 800, 1500, 3000, 5000].forEach(function(t) { setTimeout(hookjQ, t); });
  console.log('[NC Ext] Hooks actifs');
}

// Lit __nc_jwt__ depuis localStorage de la page
function readLocalToken() {
  try { return localStorage.getItem('__nc_jwt__'); } catch(e) { return null; }
}

// ═══════════════════════════════════════════════════════════
// INJECTION dans un onglet meteo.nc
// ═══════════════════════════════════════════════════════════
async function injectCapture(tabId) {
  try {
    // 1. Injecter le capteur dans MAIN world
    await chrome.scripting.executeScript({
      target: { tabId: tabId },
      func: captureTokenInPage,
      world: 'MAIN',
      injectImmediately: true
    });
  } catch(e) {
    console.warn('[NC Ext] inject MAIN err:', e.message);
  }
}

// ═══════════════════════════════════════════════════════════
// LECTURE du token depuis un onglet
// ═══════════════════════════════════════════════════════════
async function readTokenFromTab(tabId) {
  try {
    var res = await chrome.scripting.executeScript({
      target: { tabId: tabId },
      func: readLocalToken,
      world: 'MAIN'
    });
    return res && res[0] && res[0].result;
  } catch(e) { return null; }
}

// ═══════════════════════════════════════════════════════════
// SAUVEGARDE & PROPAGATION du token
// ═══════════════════════════════════════════════════════════
// Push token vers Supabase pour acces mobile
async function pushTokenToSupabase(tok) {
  if (!tok) return;
  try {
    await fetch('https://tiiptlozingmgzcnexpu.supabase.co/rest/v1/shared_tokens', {
      method: 'POST',
      headers: {
        'apikey': 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InRpaXB0bG96aW5nbWd6Y25leHB1Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzYwNTQyNTAsImV4cCI6MjA5MTYzMDI1MH0.ksgIzAgUWCAbt76S33PD9_o-52zyifGik1MLtBv9vF0',
        'Authorization': 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InRpaXB0bG96aW5nbWd6Y25leHB1Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzYwNTQyNTAsImV4cCI6MjA5MTYzMDI1MH0.ksgIzAgUWCAbt76S33PD9_o-52zyifGik1MLtBv9vF0',
        'Content-Type': 'application/json',
        'Prefer': 'resolution=merge-duplicates'
      },
      body: JSON.stringify({
        id: 'meteo-nc',
        token: tok,
        updated_at: new Date().toISOString()
      })
    });
    console.log('[NC Ext] Token pushed to Supabase (mobile sync)');
  } catch(e) { console.warn('[NC Ext] Supabase push failed:', e.message); }
}

async function saveToken(tok) {
  if (!tok || tok.length < 30) return;
  await chrome.storage.local.set({ ncToken: tok, ncTokenDate: Date.now() });
  // Aussi pousser vers Supabase pour les mobiles
  pushTokenToSupabase(tok);
  console.log('[NC Ext] Token sauvegardé:', tok.slice(0, 30) + '...');
  // Propager vers l'app surf-journal (tous les onglets ouverts)
  var appTabs = await chrome.tabs.query({ url: ['https://thibsurf.github.io/*'] });
  for (var tab of appTabs) {
    try {
      await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: function(tok) {
          try {
            localStorage.setItem('nc-token', tok);
            window.dispatchEvent(new CustomEvent('nc-token-updated', { detail: tok }));
            console.log('[NC Ext] Token injecté dans app');
          } catch(e) {}
        },
        args: [tok],
        world: 'MAIN'
      });
    } catch(e) {}
  }
}

// ═══════════════════════════════════════════════════════════
// RENOUVELLEMENT AUTOMATIQUE
// ═══════════════════════════════════════════════════════════
async function autoRefresh() {
  console.log('[NC Ext] Renouvellement auto...');

  // 1. Onglet meteo.nc déjà ouvert ?
  var existing = await chrome.tabs.query({ url: ['https://meteo.nc/*', 'https://*.meteo.nc/*'] });
  if (existing.length > 0) {
    var tok = await readTokenFromTab(existing[0].id);
    if (tok) { await saveToken(tok); scheduleNext(); return; }
  }

  // 2. Ouvrir un onglet en arrière-plan
  var tab;
  try {
    tab = await chrome.tabs.create({ url: 'https://meteo.nc', active: false });
  } catch(e) { scheduleNext(); return; }

  // 3. Attendre le chargement et la capture (max 20s)
  var tok = null;
  for (var i = 0; i < 20 && !tok; i++) {
    await new Promise(function(r) { setTimeout(r, 1000); });
    tok = await readTokenFromTab(tab.id);
  }

  if (tok) await saveToken(tok);
  else console.warn('[NC Ext] Token non capturé');

  try { await chrome.tabs.remove(tab.id); } catch(e) {}
  scheduleNext();
}

function scheduleNext() {
  var next = Date.now() + 6 * 3600 * 1000;
  chrome.storage.local.set({ ncNextRefresh: next });
}

// ═══════════════════════════════════════════════════════════
// EVENTS
// ═══════════════════════════════════════════════════════════

// Onglet meteo.nc chargé → injecter le capteur
chrome.tabs.onUpdated.addListener(function(tabId, info, tab) {
  if (!tab.url) return;
  var isMeteo = tab.url.includes('meteo.nc');
  if (isMeteo && info.status === 'loading') {
    injectCapture(tabId);
  }
});

// Messages depuis content.js (token capturé via postMessage)
chrome.runtime.onMessage.addListener(function(msg, sender, sendResponse) {
  if (msg.type === 'NC_TOKEN' && msg.token) {
    saveToken(msg.token);
    sendResponse({ ok: true });
    return true;
  }
  if (msg.type === 'POPUP_GET') {
    chrome.storage.local.get(['ncToken', 'ncTokenDate', 'ncNextRefresh'], function(d) {
      sendResponse(d);
    });
    return true;
  }
  if (msg.type === 'FORCE_REFRESH') {
    autoRefresh().then(function() { sendResponse({ ok: true }); })
      .catch(function(e) { sendResponse({ ok: false, err: e.message }); });
    return true;
  }
});

// Alarme Chrome (plus fiable que setTimeout dans service worker)
chrome.alarms.onAlarm.addListener(function(alarm) {
  if (alarm.name === 'nc-auto') autoRefresh();
});

// Installation → premier refresh immédiat + alarme
chrome.runtime.onInstalled.addListener(function() {
  chrome.alarms.create('nc-auto', { periodInMinutes: 360 });
  scheduleNext();
  setTimeout(autoRefresh, 3000);
});

// Démarrage navigateur → refresh si token vieux (>20h)
chrome.runtime.onStartup.addListener(function() {
  chrome.alarms.create('nc-auto', { periodInMinutes: 360 });
  chrome.storage.local.get(['ncTokenDate'], function(d) {
    if (Date.now() - (d.ncTokenDate || 0) > 20 * 3600 * 1000) {
      setTimeout(autoRefresh, 3000);
    }
  });
});
