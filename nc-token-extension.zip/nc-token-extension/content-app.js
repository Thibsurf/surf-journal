// Content script sur surf-journal — synchronise le token avec localStorage de l'app
(function() {
  // 1. Au chargement: lire le token depuis chrome.storage et l'injecter dans localStorage
  function syncFromStorage() {
    chrome.storage.local.get(['ncToken', 'ncTokenDate'], function(d) {
      if (!d.ncToken) return;
      // Injecter dans localStorage de l'app
      injectToken(d.ncToken);
    });
  }

  // Passer par postMessage car chrome.storage n'est pas accessible depuis MAIN world
  // On injecte un script qui met à jour localStorage
  function injectToken(token) {
    var script = document.createElement('script');
    script.textContent = 'try { localStorage.setItem("nc-token", ' + JSON.stringify(token) + '); '
      + 'window.dispatchEvent(new CustomEvent("nc-token-updated", {detail: ' + JSON.stringify(token) + '})); } catch(e){}';
    (document.head || document.documentElement).appendChild(script);
    script.remove();
    console.log('[NC Token Ext] Token synchronisé avec surf-journal');
  }

  // 2. Écouter les changements du token dans chrome.storage
  chrome.storage.onChanged.addListener(function(changes, area) {
    if (area === 'local' && changes.ncToken && changes.ncToken.newValue) {
      injectToken(changes.ncToken.newValue);
    }
  });

  // Sync immédiat au chargement
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', syncFromStorage);
  } else {
    syncFromStorage();
  }
  syncFromStorage(); // double pour être sûr

  console.log('[NC Token Ext] Sync actif sur surf-journal');
})();
