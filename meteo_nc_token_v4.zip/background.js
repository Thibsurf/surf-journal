'use strict';

// ═══════════════════════════════════════════════════════════════
// CONFIG
// ═══════════════════════════════════════════════════════════════
const SUPABASE_URL  = 'https://tiiptlozingmgzcnexpu.supabase.co/rest/v1/shared_tokens';
const SUPABASE_ANON = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InRpaXB0bG96aW5nbWd6Y25leHB1Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzYwNTQyNTAsImV4cCI6MjA5MTYzMDI1MH0.ksgIzAgUWCAbt76S33PD9_o-52zyifGik1MLtBv9vF0';

// Durée de vie max du token avant refresh forcé (20h — expire ~24h)
const TOKEN_MAX_AGE_MS = 20 * 60 * 60 * 1000;

// URL de refresh : ouvre meteo.nc en arrière-plan pour déclencher content.js
const METEO_URL = 'https://meteo.nc/fr/meteo/noumea';

// ═══════════════════════════════════════════════════════════════
// VALIDATION JWT
// ═══════════════════════════════════════════════════════════════
function isJWT(t) {
  return typeof t === 'string' &&
    /^[A-Za-z0-9\-_]{10,}\.[A-Za-z0-9\-_]{10,}\.[A-Za-z0-9\-_]{10,}$/.test(t);
}

// ═══════════════════════════════════════════════════════════════
// STORAGE — SOURCE UNIQUE DE VÉRITÉ
// ═══════════════════════════════════════════════════════════════
async function getStored() {
  return chrome.storage.local.get(['ncToken', 'ncTokenDate', 'ncRefreshCount']);
}

async function saveToken(token, source) {
  if (!isJWT(token)) {
    console.warn('[BG] Token invalide, ignoré');
    return false;
  }
  const { ncToken } = await getStored();
  if (ncToken === token) return false; // déduplique

  const count = (await getStored()).ncRefreshCount || 0;
  await chrome.storage.local.set({
    ncToken: token,
    ncTokenDate: Date.now(),
    ncTokenSource: source || 'unknown',
    ncRefreshCount: count + 1
  });
  console.log(`[BG] ✅ Token sauvé (source: ${source})`);

  // Pousser vers Supabase (mobile sync)
  pushToSupabase(token).catch(() => {});

  // Notifier tous les onglets de l'app
  notifyAppTabs(token);

  // Mettre à jour le badge
  setBadge('✓', '#3dba8a');

  return true;
}

// ═══════════════════════════════════════════════════════════════
// SUPABASE SYNC
// ═══════════════════════════════════════════════════════════════
async function pushToSupabase(token) {
  try {
    const res = await fetch(SUPABASE_URL, {
      method: 'POST',
      headers: {
        'apikey': SUPABASE_ANON,
        'Authorization': `Bearer ${SUPABASE_ANON}`,
        'Content-Type': 'application/json',
        'Prefer': 'resolution=merge-duplicates'
      },
      body: JSON.stringify({
        id: 'meteo-nc',
        token: token,
        updated_at: new Date().toISOString()
      })
    });
    if (res.ok) console.log('[BG] ☁️ Supabase synced');
    else console.warn('[BG] Supabase error:', res.status);
  } catch (e) {
    console.warn('[BG] Supabase push failed:', e.message);
  }
}

// ═══════════════════════════════════════════════════════════════
// NOTIFIER L'APP (content-app.js l'écoute déjà via onChanged)
// On force aussi un postMessage direct si l'onglet est ouvert
// ═══════════════════════════════════════════════════════════════
async function notifyAppTabs(token) {
  try {
    const tabs = await chrome.tabs.query({ url: 'https://thibsurf.github.io/*' });
    for (const tab of tabs) {
      chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: (tok) => {
          window.postMessage({ type: '__nc_set_token__', token: tok }, '*');
        },
        args: [token]
      }).catch(() => {});
    }
  } catch (e) {}
}

// ═══════════════════════════════════════════════════════════════
// BADGE
// ═══════════════════════════════════════════════════════════════
function setBadge(text, color) {
  chrome.action.setBadgeText({ text: String(text) });
  chrome.action.setBadgeBackgroundColor({ color: color || '#3d5468' });
}

// ═══════════════════════════════════════════════════════════════
// LECTURE COOKIE meteo.nc
// Méthode la plus fiable : le cookie "token" est planté par
// l'API meteo.nc lors de l'authentification
// ═══════════════════════════════════════════════════════════════
async function tryReadCookie() {
  try {
    const cookie = await chrome.cookies.get({
      url: 'https://meteo.nc',
      name: 'token'
    });
    if (cookie && isJWT(cookie.value)) {
      console.log('[BG] 🍪 Cookie token trouvé');
      return cookie.value;
    }
    // Essai nom alternatif
    const cookie2 = await chrome.cookies.get({
      url: 'https://meteo.nc',
      name: 'jwt'
    });
    if (cookie2 && isJWT(cookie2.value)) return cookie2.value;

    // Scan tous les cookies meteo.nc
    const all = await chrome.cookies.getAll({ domain: 'meteo.nc' });
    for (const c of all) {
      if (isJWT(c.value)) {
        console.log('[BG] 🍪 Cookie JWT trouvé:', c.name);
        return c.value;
      }
    }
  } catch (e) {
    console.warn('[BG] Cookie read failed:', e.message);
  }
  return null;
}

// ═══════════════════════════════════════════════════════════════
// REFRESH AUTOMATIQUE
// Ouvre un onglet meteo.nc invisible → content.js le scanne
// ET on lit les cookies directement
// ═══════════════════════════════════════════════════════════════
let _refreshInProgress = false;

async function doRefresh() {
  if (_refreshInProgress) return;
  _refreshInProgress = true;
  console.log('[BG] 🔄 Refresh en cours...');
  setBadge('...', '#e8a057');

  try {
    // 1. Essai rapide via cookie (pas besoin d'ouvrir un onglet)
    const cookieTok = await tryReadCookie();
    if (cookieTok) {
      const saved = await saveToken(cookieTok, 'cookie');
      if (saved) { _refreshInProgress = false; return; }
    }

    // 2. Si pas de cookie, ouvrir meteo.nc en background
    // content.js va scanner la page et envoyer le token via message
    const tab = await chrome.tabs.create({
      url: METEO_URL,
      active: false,
      pinned: false
    });

    // Attendre que content.js scanne (max 8s) puis fermer l'onglet
    await new Promise(r => setTimeout(r, 8000));

    // Re-tenter le cookie après chargement de la page
    const cookieTok2 = await tryReadCookie();
    if (cookieTok2) await saveToken(cookieTok2, 'cookie-after-load');

    // Fermer l'onglet silencieusement
    chrome.tabs.remove(tab.id).catch(() => {});

  } catch (e) {
    console.warn('[BG] Refresh error:', e.message);
    setBadge('!', '#e05c5c');
  } finally {
    _refreshInProgress = false;
  }
}

// ═══════════════════════════════════════════════════════════════
// VÉRIFICATION EXPIRY ET REFRESH PROGRAMMÉ
// ═══════════════════════════════════════════════════════════════
async function checkAndRefreshIfNeeded() {
  const { ncToken, ncTokenDate } = await getStored();
  const age = ncTokenDate ? Date.now() - ncTokenDate : Infinity;

  if (!ncToken || !isJWT(ncToken)) {
    console.log('[BG] Pas de token → refresh');
    setBadge('?', '#e05c5c');
    doRefresh();
    return;
  }

  if (age > TOKEN_MAX_AGE_MS) {
    console.log(`[BG] Token âgé de ${Math.round(age/3600000)}h → refresh`);
    setBadge('↺', '#e8a057');
    doRefresh();
    return;
  }

  const remainH = Math.round((TOKEN_MAX_AGE_MS - age) / 3600000);
  console.log(`[BG] Token OK, expire dans ~${remainH}h`);
  setBadge('✓', '#3dba8a');
}

// ═══════════════════════════════════════════════════════════════
// MESSAGES (depuis content.js, popup.js, content-app.js)
// ═══════════════════════════════════════════════════════════════
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {

  // Token capturé par content.js sur meteo.nc
  if (msg.type === 'NC_TOKEN') {
    console.log('[BG] 📩 Token reçu de content.js');
    saveToken(msg.token, 'content-dom').then(saved => {
      sendResponse({ ok: true, saved });
    });
    return true;
  }

  // Popup : lire l'état
  if (msg.type === 'POPUP_GET') {
    getStored().then(d => sendResponse(d || {}));
    return true;
  }

  // Popup : forcer refresh
  if (msg.type === 'FORCE_REFRESH') {
    doRefresh();
    sendResponse({ ok: true });
    return true;
  }

  // Popup : effacer le token
  if (msg.type === 'CLEAR_TOKEN') {
    chrome.storage.local.remove(['ncToken', 'ncTokenDate', 'ncTokenSource', 'ncRefreshCount']);
    setBadge('', '#3d5468');
    sendResponse({ ok: true });
    return true;
  }
});

// ═══════════════════════════════════════════════════════════════
// ALARMES — refresh périodique toutes les 6h
// ═══════════════════════════════════════════════════════════════
chrome.alarms.create('token-refresh', {
  delayInMinutes: 30,        // premier check dans 30min
  periodInMinutes: 6 * 60   // puis toutes les 6h
});

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'token-refresh') {
    console.log('[BG] ⏰ Alarm → checkAndRefresh');
    checkAndRefreshIfNeeded();
  }
});

// ═══════════════════════════════════════════════════════════════
// INSTALL / STARTUP
// ═══════════════════════════════════════════════════════════════
chrome.runtime.onInstalled.addListener(() => {
  console.log('[BG] Extension installée v4.0');
  checkAndRefreshIfNeeded();
});

chrome.runtime.onStartup.addListener(() => {
  console.log('[BG] Chrome démarré → check token');
  checkAndRefreshIfNeeded();
});
