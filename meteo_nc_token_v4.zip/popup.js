'use strict';

// ═══════════════════════════════════════════════════════════════
// HELPERS
// ═══════════════════════════════════════════════════════════════
function $(id) { return document.getElementById(id); }

function formatAge(ms) {
  if (!ms) return 'jamais';
  const age = Date.now() - ms;
  const m = Math.round(age / 60000);
  if (m < 1)  return 'à l\'instant';
  if (m < 60) return `il y a ${m} min`;
  const h = Math.floor(m / 60);
  const rm = m % 60;
  return `il y a ${h}h${rm > 0 ? String(rm).padStart(2,'0') : ''}`;
}

function formatDateTime(ms) {
  if (!ms) return '—';
  return new Date(ms).toLocaleString('fr-FR', {
    day: '2-digit', month: '2-digit',
    hour: '2-digit', minute: '2-digit'
  });
}

const TOKEN_MAX_AGE_MS = 20 * 60 * 60 * 1000; // 20h

// ═══════════════════════════════════════════════════════════════
// AFFICHAGE STATUS
// ═══════════════════════════════════════════════════════════════
function render(d) {
  const box    = $('status-box');
  const icon   = $('status-icon');
  const main   = $('status-main');
  const sub    = $('status-sub');
  const ageW   = $('age-wrap');
  const ageTxt = $('age-text');
  const ageFill= $('age-fill');
  const details= $('details');

  if (!d || !d.ncToken) {
    box.className = 'status-box err';
    icon.textContent = '❌';
    main.textContent = 'Aucun token';
    sub.textContent  = 'Visitez meteo.nc ou cliquez Renouveler';
    if (ageW) ageW.style.display = 'none';
    if (details) details.style.display = 'none';
    return;
  }

  const age = d.ncTokenDate ? Date.now() - d.ncTokenDate : Infinity;
  const frac = Math.min(1, age / TOKEN_MAX_AGE_MS);
  const remainH = Math.round((TOKEN_MAX_AGE_MS - age) / 3600000);

  // Couleur barre selon âge
  let barColor, boxClass, iconTxt, mainTxt, subTxt;
  if (frac < 0.5) {
    barColor = '#3dba8a'; boxClass = 'ok'; iconTxt = '✅';
    mainTxt = 'Token actif'; subTxt = `Valide encore ~${remainH}h`;
  } else if (frac < 0.85) {
    barColor = '#e8a057'; boxClass = 'warn'; iconTxt = '⚠️';
    mainTxt = 'Token vieillissant'; subTxt = `Expire dans ~${remainH}h — pensez à renouveler`;
  } else {
    barColor = '#e05c5c'; boxClass = 'err'; iconTxt = '🔴';
    mainTxt = 'Token presque expiré'; subTxt = remainH > 0 ? `Plus que ~${remainH}h` : 'Probablement expiré — renouveler maintenant';
  }

  box.className = 'status-box ' + boxClass;
  icon.textContent = iconTxt;
  main.textContent = mainTxt;
  sub.textContent  = subTxt;

  // Barre d'âge
  if (ageW) ageW.style.display = 'block';
  if (ageTxt) ageTxt.textContent = formatAge(d.ncTokenDate);
  if (ageFill) {
    ageFill.style.width = Math.round(frac * 100) + '%';
    ageFill.style.background = barColor;
  }

  // Détails
  $('det-source').textContent = d.ncTokenSource || 'inconnu';
  $('det-date').textContent   = formatDateTime(d.ncTokenDate);
  $('det-count').textContent  = d.ncRefreshCount || 0;
  $('det-token').textContent  = d.ncToken
    ? d.ncToken.substring(0, 20) + '…' + d.ncToken.slice(-10)
    : '—';
}

// ═══════════════════════════════════════════════════════════════
// REFRESH ÉTAT
// ═══════════════════════════════════════════════════════════════
function loadStatus() {
  chrome.runtime.sendMessage({ type: 'POPUP_GET' }, (d) => {
    if (chrome.runtime.lastError) {
      $('status-main').textContent = '❌ Extension inactive';
      $('status-sub').textContent = 'Rechargez l\'extension';
      return;
    }
    render(d);
    const fc = $('footer-count');
    if (fc && d && d.ncRefreshCount) {
      fc.textContent = `${d.ncRefreshCount} renouvellement(s)`;
    }
  });
}

// ═══════════════════════════════════════════════════════════════
// INIT
// ═══════════════════════════════════════════════════════════════
document.addEventListener('DOMContentLoaded', () => {

  loadStatus();

  // Renouveler
  $('btn-refresh').onclick = () => {
    $('status-main').textContent = 'Renouvellement en cours…';
    $('status-sub').innerHTML = '<span class="spin"></span>Ouverture de meteo.nc…';
    $('btn-refresh').disabled = true;
    chrome.runtime.sendMessage({ type: 'FORCE_REFRESH' });
    // Rafraîchir l'affichage après 10s (temps pour que meteo.nc charge)
    setTimeout(() => {
      $('btn-refresh').disabled = false;
      loadStatus();
    }, 10000);
  };

  // Ouvrir Surf NC
  $('btn-app').onclick = () => {
    chrome.tabs.create({
      url: 'https://thibsurf.github.io/surf-journal/previsions.html'
    });
  };

  // Toggle détails
  let detailsVisible = false;
  $('btn-details').onclick = () => {
    detailsVisible = !detailsVisible;
    $('details').style.display = detailsVisible ? 'block' : 'none';
    $('btn-details').textContent = detailsVisible ? 'Masquer' : 'Détails';
  };

  // Effacer
  $('btn-clear').onclick = () => {
    if (!confirm('Effacer le token stocké ?')) return;
    chrome.runtime.sendMessage({ type: 'CLEAR_TOKEN' });
    setTimeout(loadStatus, 300);
  };
});
