'use strict';

// ═══════════════════════════════════════════════════════════════
// content.js — Injecté sur meteo.nc
// Stratégies multiples pour trouver le JWT, du plus fiable au moins
// ═══════════════════════════════════════════════════════════════

function isJWT(t) {
  return typeof t === 'string' &&
    /^[A-Za-z0-9\-_]{10,}\.[A-Za-z0-9\-_]{10,}\.[A-Za-z0-9\-_]{10,}$/.test(t);
}

function sendToken(token, source) {
  if (!isJWT(token)) return false;
  chrome.runtime.sendMessage({ type: 'NC_TOKEN', token, source });
  console.log('[CONTENT] Token envoyé (source:', source, ')');
  return true;
}

// ═══════════════════════════════════════════════════════════════
// STRATÉGIE 1 : Intercepter fetch/XHR AVANT qu'ils soient appelés
// Injecte un script dans la page (world: MAIN) pour intercepter
// les headers Authorization envoyés par le code JS de meteo.nc
// ═══════════════════════════════════════════════════════════════
function injectFetchInterceptor() {
  const script = document.createElement('script');
  script.textContent = `(function() {
    const JWT_RE = /^[A-Za-z0-9\\-_]{10,}\\.[A-Za-z0-9\\-_]{10,}\\.[A-Za-z0-9\\-_]{10,}$/;
    
    // Intercepter fetch
    const _fetch = window.fetch;
    window.fetch = function(url, opts) {
      try {
        const auth = opts && opts.headers && (
          (opts.headers instanceof Headers ? opts.headers.get('authorization') : null)
          || opts.headers['Authorization']
          || opts.headers['authorization']
        );
        if (auth) {
          const tok = auth.replace(/^Bearer\\s+/i, '').trim();
          if (JWT_RE.test(tok)) {
            window.dispatchEvent(new CustomEvent('__nc_jwt_captured__', { detail: tok }));
          }
        }
      } catch(e) {}
      return _fetch.apply(this, arguments);
    };

    // Intercepter XMLHttpRequest
    const _open = XMLHttpRequest.prototype.open;
    const _setHeader = XMLHttpRequest.prototype.setRequestHeader;
    XMLHttpRequest.prototype.setRequestHeader = function(name, value) {
      if (name && name.toLowerCase() === 'authorization' && value) {
        const tok = value.replace(/^Bearer\\s+/i, '').trim();
        if (JWT_RE.test(tok)) {
          window.dispatchEvent(new CustomEvent('__nc_jwt_captured__', { detail: tok }));
        }
      }
      return _setHeader.apply(this, arguments);
    };

    console.log('[NC-inject] Fetch/XHR intercepteur actif');
  })();`;
  
  // Injecter AVANT que la page charge son JS
  (document.head || document.documentElement).appendChild(script);
  script.remove();
}

// Écouter les événements de l'intercepteur
window.addEventListener('__nc_jwt_captured__', (e) => {
  if (e.detail) sendToken(e.detail, 'fetch-intercept');
});

// ═══════════════════════════════════════════════════════════════
// STRATÉGIE 2 : Scan localStorage de meteo.nc
// ═══════════════════════════════════════════════════════════════
function scanLocalStorage() {
  try {
    const keys = ['token', '__nc_jwt__', 'jwt', 'auth_token', 'access_token', 'bearer'];
    for (const k of keys) {
      const v = localStorage.getItem(k);
      if (isJWT(v)) return sendToken(v, 'localStorage:' + k);
    }
    // Scan général
    for (let i = 0; i < localStorage.length; i++) {
      const k = localStorage.key(i);
      const v = localStorage.getItem(k);
      if (isJWT(v)) return sendToken(v, 'localStorage-scan:' + k);
    }
  } catch (e) {}
  return false;
}

// ═══════════════════════════════════════════════════════════════
// STRATÉGIE 3 : Scan sessionStorage
// ═══════════════════════════════════════════════════════════════
function scanSessionStorage() {
  try {
    for (let i = 0; i < sessionStorage.length; i++) {
      const k = sessionStorage.key(i);
      const v = sessionStorage.getItem(k);
      if (isJWT(v)) return sendToken(v, 'sessionStorage:' + k);
    }
  } catch (e) {}
  return false;
}

// ═══════════════════════════════════════════════════════════════
// STRATÉGIE 4 : Scan des scripts inline
// Certains sites initialisent window.__config = { token: "eyJ..." }
// ═══════════════════════════════════════════════════════════════
function scanScripts() {
  try {
    const scripts = document.querySelectorAll('script:not([src])');
    const JWT_RE = /eyJ[A-Za-z0-9\-_]+\.[A-Za-z0-9\-_]+\.[A-Za-z0-9\-_]+/g;
    for (const s of scripts) {
      const txt = s.textContent || '';
      const matches = txt.match(JWT_RE);
      if (matches) {
        for (const m of matches) {
          if (isJWT(m)) return sendToken(m, 'script-inline');
        }
      }
    }
  } catch (e) {}
  return false;
}

// ═══════════════════════════════════════════════════════════════
// SCAN COMPLET — toutes stratégies DOM/storage
// ═══════════════════════════════════════════════════════════════
function fullScan() {
  if (scanLocalStorage()) return;
  if (scanSessionStorage()) return;
  if (scanScripts()) return;
  // Pas trouvé → background essaiera via cookie
}

// ═══════════════════════════════════════════════════════════════
// OBSERVER DOM — scrute les nouveaux scripts injectés dynamiquement
// (meteo.nc charge son auth de façon asynchrone)
// ═══════════════════════════════════════════════════════════════
let _lastScan = 0;
const observer = new MutationObserver(() => {
  const now = Date.now();
  if (now - _lastScan < 300) return; // throttle 300ms
  _lastScan = now;
  fullScan();
});

// ═══════════════════════════════════════════════════════════════
// INIT
// ═══════════════════════════════════════════════════════════════

// Injecter l'intercepteur fetch immédiatement (document_start)
injectFetchInterceptor();

// Observer le DOM dès que possible
if (document.documentElement) {
  observer.observe(document.documentElement, { childList: true, subtree: true });
}

// Scans différés après chargement
window.addEventListener('load', () => {
  setTimeout(fullScan, 500);
  setTimeout(fullScan, 2000);
  setTimeout(fullScan, 5000);
  
  // Arrêter l'observer après 15s (page chargée)
  setTimeout(() => observer.disconnect(), 15000);
});

// Scan rapide dès document_start
setTimeout(fullScan, 100);

console.log('[CONTENT] meteo.nc scanner v4.0 actif');
