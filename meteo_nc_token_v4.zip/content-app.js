'use strict';

// ═══════════════════════════════════════════════════════════════
// content-app.js — Injecté sur thibsurf.github.io
// Envoie le token stocké vers l'app via postMessage
// ═══════════════════════════════════════════════════════════════

function sendTokenToApp(token) {
  if (!token) return;
  window.postMessage({ type: '__nc_set_token__', token }, '*');
  console.log('[CONTENT-APP] Token injecté dans l\'app');
}

// 1. Envoi immédiat au chargement
chrome.storage.local.get(['ncToken'], (d) => {
  if (d.ncToken) sendTokenToApp(d.ncToken);
});

// 2. Écoute les mises à jour du token (quand meteo.nc est visité)
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'local' && changes.ncToken && changes.ncToken.newValue) {
    sendTokenToApp(changes.ncToken.newValue);
  }
});
